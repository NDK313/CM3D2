﻿※KISS公式ブログに記載されているMOD利用規約
　 ・MODはKISSサポート対象外です。
　 ・MODを利用するに当たり、問題が発生しても製作者・KISSは一切の責任を負いかねます。
　 ・カスタムメイド3D2を購入されている方のみが利用できます。
　 ・カスタムメイド3D2上で表示する目的以外の利用は禁止します。

※지원 버전
  ・CM3D2x86
  ・CM3D2x64
  ・CM3D2OHx86
  ・CM3D2OHx64

※동작 확인
  ・CM3D2x86 Ver.1.36
  ・CM3D2x64 Ver.1.36
  ・CM3D2x86 Ver.1.37
  ・CM3D2x64 Ver.1.37
  ・CM3D2x86 Ver.1.37.1
  ・CM3D2x64 Ver.1.37.1
  ・CM3D2x86 Ver.1.38
  ・CM3D2x64 Ver.1.38
  ・しばりす build160410
  ・Windows 10 Home x64

※전제 조건
  ・CM3D2가 CLR 2.0.50727.1433버전으로 작동해야 합니다.
  ・"UnityInjector" 가 정상적으로 작동해야 합니다.

※플러그인 소개
  ・다른 플러그인에서 사용되는, 유니티에서 기본적으로 제공하는 GUI의 문자열을 번역해주는 플러그인입니다.

※설치 방법
  ・"UnityInjector" 폴더를 기존 "UnityInjector" 폴더에 덮어씌우시면 됩니다.

※사용 방법
  ・번역 활성화, 추출 활성화를 켜신 상태로 다른 플러그인의 GUI와 이챠이챠하다 보면 한 번이라도 표시된 문자열은 추출되어 있습니다.
  새로 고침하시거나 번역 활성화를 끄시면 추출된 문자열이 설정 파일에 저장되므로 이후에 손... 번역하시면 됩니다.

※키 종류
  ◇'f1' : 번역 활성화 토글 키
    ・번역의 여부를 설정합니다.
    ・설정 파일을 새로 고침합니다.

  ◇'r' : 새로 고침 키
    ・번역 활성화가 켜져 있어야 합니다.
    ・설정 파일을 새로 고침합니다.
    ・CM3D2가 켜진 상태로 번역, 추출하실 때 유용합니다.

※설정 파일
  ・설정 파일의 위치는 플러그인이 있는 곳에서(상대 경로) "Config/UnityGuiTranslation.txt" 입니다.
  "UnityGuiTranslation.txt" 파일은 없어도 자동 생성됩니다만 "Config" 폴더는 없으면 에러 납니다.

  ・설정 파일에는 여러 가지의 설정이 다음과 같은 형식으로 분할되어 있습니다.
  "===&설정 이름&==="
  "설정 =#> 값"
  "설정 ==> 값"
  "설정 =/> 값"
  "===&ConfigEnd&==="
  형식이 올바르지 않으면 그와 관련된 설정은 몽땅 날아가 버립니다.

  ◇설정 종류
    ◇플러그인 설정
      ・"ExtractionActivate" : 추출 활성화 설정입니다.
      ・"TranslationActivateDefault" : 번역 활성화 기본 설정입니다.
      ・"TranslationActivateToggleKey" : 번역 활성화 토글 키 설정입니다.
      ・"TranslationRefreshKey" : 새로 고침 키 설정입니다.
      ・키의 목록은 다음 문서 하단을 참조
      https://docs.unity3d.com/Manual/ConventionalGameInput.html

    ◇속성 설정
      ・"DateTimeRegex" : 날짜의 추출 정규식입니다.
      ・"DateTimeString" : 날짜의 출력 패턴입니다.
      ・"NumberRegex" : 문장 번역 설정에서 사용하는 숫자의 추출 정규식입니다.
      ・"NumberReplacementCharacter" : 문장 번역 설정에서 사용하는 숫자의 대체 문자입니다.
      ・"SectionStringMaxLength" : 섹션 문자열의 최대 길이입니다.
      ・"WordMinByteLength" : 단어 번역 설정에서 사용하는 단어의 최소 (UTF8)Byte길이입니다.
      ・"WordRegex" : 단어 번역 설정에서 사용하는 단어의 추출 정규식입니다.
      ・보통 건들 일은 없다고 생각합니다만 건들고 싶으시다면 다음 문서를 참조
      https://msdn.microsoft.com/ko-kr/library/hs600312(v=vs.90).aspx
    
    ◇후크 메서드 설정 (CM3D2 재실행 필요)
      ・"HookBeginGroup" : "GUI Area, Group" 을 담당하는 메서드의 후크 설정입니다.
      ・"HookBox" : "GUI Horizontal, Vertical, Box" 를 담당하는 메서드의 후크 설정입니다.
      ・"HookDoButton" : "GUI Button" 을 담당하는 메서드의 후크 설정입니다.
      ・"HookDoButtonGrid" : "GUI SelectionGrid, Toolbar" 를 담당하는 메서드의 후크 설정입니다.
      ・"HookDoLabel" : "GUI Label" 을 담당하는 메서드의 후크 설정입니다.
      ・"HookDoModalWindow" : "GUI ModalWindow" 를 담당하는 메서드의 후크 설정입니다.
      ・"HookDoRepeatButton" : "GUI RepeatButton, ScrollerRepeatButton" 을 담당하는 메서드의 후크 설정입니다.
      ・"HookDoTextField" : "GUI PasswordField, TextArea, TextField" 를 담당하는 메서드의 후크 설정입니다.
      ・"HookDoToggle" : "GUI Toggle" 을 담당하는 메서드의 후크 설정입니다.
      ・"HookDoWindow" : "GUI Window" 를 담당하는 메서드의 후크 설정입니다.

    ◇단어 번역 설정
      ・문장 번역 설정의 번역할 문자열에서 숫자, 문장 부호, 연결선, 특수문자, 공백을 제외하고 추출한 (UTF8)3Byte이상인 단어입니다.
      ・대게 번역은 이곳에서 하는 것이 좋습니다만 하나의 문장에만 간섭하는게 아니니 직역을 추천합니다.

    ◇문장 번역 설정
      ・다른 플러그인의 GUI에서 추출된 문장입니다.
      ・숫자는 전부 '%d%' 문자로 통합해버리는데 원본 문자열과 번역할 문자열의 '%d%' 문자 개수가 같아야지만 숫자가 정상 출력됩니다.
      ・전부 손 번역을 하기엔 추출되는 문자열이 너무 많으니 일부 문자열을 의역을 하고 싶으실 때만 추천합니다.
      이때 단어 번역 설정이 문장 번역 설정의 번역할 문자열에서 단어를 추출하니 그런 일이 없도록 절대 지정을 해주세요.

  ・지정 코드에서 왼쪽에 있는 문자열이 설정 이름, 오른쪽에 있는 문자열이 설정 값입니다.
  단어 번역 설정이나 문장 번역 설정은 왼쪽이 원본 문자열, 오른쪽이 번역할 문자열이라고 생각하시면 됩니다.

  ◇지정 코드 (띄어쓰기 포함)
    ・" =#> " : 상대 지정 문자입니다. 다른 설정에 간섭받을 수 있습니다.
    ・" ==> " : 절대 지정 문자입니다. 다른 설정에 간섭받을 수 없습니다.
    ・" =/> " : 사용 안 함 지정 문자입니다. 무조건 원본 값으로 적용됩니다.

  ◇단어 번역 설정, 문장 번역 설정의 날짜
    ・중간중간에 있는 날짜는 그 아래에 있는 번역 설정의 마지막 추출 날짜입니다.
    ・새로운 단어, 문장을 추출, 번역할 때 확인하기 편합니다.
    ・날짜는 지우셔도 무방합니다.

※설정 파일 병합
  ・가장 뒤에 있는 설정을 우선시하기 때문에 원하시는 설정을 줄 단위로 복사하신 후 자기 설정 파일에서 원하시는 설정의 맨 아랫줄에 붙여넣기 하시면 됩니다.

※번역된 플러그인
  ・ColorPaletteHelper 0.3.1
  ・CycloneX10 0.1.1.0
  ・EditceneUndo 0.2.0.0
  ・FaceControl 0.0.4.0
  ・HalfDressing 0.0.0.8
  ・Multimaid 18.0.1
  ・PngPlacement 0.5.0.0
  ・PostEffect 0.1.0.0
  ・ShapeAnimator 0.3.5.0
  ・UnderwearAutoChanger 0.2.0.3
  ・VibeYourMaid 0.7.0.1
  ・YotogiAtmosphere 1.2.0
  ・YotogiSlider 0.1.0.8
  ・YotogiUtil 1.15.6.3

※기타
  ・일부 번역은 띄어쓰기를 하지 않았습니다.
  ・번역에 자신이 없어 의역은 하지 않았습니다.
  ・번역은 구글 번역기, 네이버 번역기, 네이버 일본어 사전을 참고했습니다.
  ・번역이 엉망입니다. 기본 한자도 모르고 일본 문화도 잘 알고 있지 않은 사람이요 번역도 처음이라 통일성이 없으니 양해 부탁드립니다.
  ・일부 문자열은 번역하지 못 했습니다. 아무래도 개개인이 만든 플러그인이다 보니 글이 다 다르고, 사심이 가득하고(?), 줄임말, 넷 용어가 많아 알기 어렵습니다.

※주의 사항
  ・번역하신 뒤 일부 GUI가 작동이 안 된다 싶으면 그와 관련된 번역 설정은 사용 안 함 지정을 해주세요.
  ・CM3D2를 완전히 끄시거나 번역 활성화, 혹은 추출 활성화를 끄시기 전까지는 메모리에 설정이 남아있으므로 설정 파일에서 어떠한 설정도 삭제하지 못 합니다.
  ・이 플러그인은 CLR 2.0.50727.1433버전에서만 작동합니다.
  CLR버전 확인은 이 플러그인이 추가될 때 콘솔 창에 출력되오니
  CM3D2가 다른 CLR에서 구동된다면 바로 플러그인을 삭제해주시고 저에게 제보해주세요.

※문의 제보
  ・http://cafe.naver.com/kisscm 카페에서 NDK(eunju313401)닉네임으로 거주하고 있습니다.

※변경 내역
  ◇1.4.3
    ・플러그인 설정에 "ExtractionActivate" 설정 추가
    ・플러그인 설정에 "TranslationDefaultActivate" 설정을 "TranslationActivateDefault" 으로 개명
    ・속성 설정에 "DateTimeSectionStringMarginCharacter" 설정 삭제
    ・속성 설정에 "DateTimeSectionStringMaxLength" 설정 삭제
    ・속성 설정에 "SectionStringMaxLength" 설정 추가
    ・속성 설정에 "StringMinimumByteLength" 설정을 "WordMinByteLength" 으로 개명
    ・속성 설정에 "StringRegex" 설정을 "WordRegex" 으로 개명
    ・설정 파일에 후크 메서드 설정 추가
    ・안정성 향상
    ・배포판 : http://cafe.naver.com/kisscm/37597

  ◇1.4.2
    ・"UnityEngine.GUI BeginGroup" 함수에 대한 후크 추가
    ・"UnityEngine.GUI Box" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoButton" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoButtonGrid" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoLabel" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoModalWindow" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoRepeatButton" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoTextField" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoToggle" 함수에 대한 후크 추가
    ・"UnityEngine.GUI DoWindow" 함수에 대한 후크 추가
    ・"UnityEngine.GUIContent text get" 프로퍼티에 대한 후크 삭제
    ・"UnityEngine.GUIContent image get" 프로퍼티에 대한 후크 삭제
    ・"UnityEngine.GUIContent tooltip get" 프로퍼티에 대한 후크 삭제
    ・"UnityEngine.GUIContent Temp(string)" 함수에 대한 후크 삭제
    ・"UnityEngine.GUIContent Temp(Texture)" 함수에 대한 후크 삭제
    ・"UnityEngine.GUIContent Temp(string, Texture)" 함수에 대한 후크 삭제
    ・"UnityEngine.GUIContent Temp(string[])" 함수에 대한 후크 삭제
    ・"UnityEngine.GUIContent Temp(texture[])" 함수에 대한 후크 삭제
    ・문자열 번역 설정을 단어 번역 설정으로 개명

  ◇1.4.1
    ・설정 파일 이름을 "UnityGuiTranslation.txt" 으로 개명
    ・플러그인 이름을 "UnityGuiTranslation" 으로 개명

  ◇1.3.7
    ・"UnityEngine.GUIContent text get" 프로퍼티에 대한 후크 추가
    ・"UnityEngine.GUIContent image get" 프로퍼티에 대한 후크 추가
    ・"UnityEngine.GUIContent tooltip get" 프로퍼티에 대한 후크 추가
    ・"UnityEngine.GUIContent Temp(string[])" 함수에 대한 후크 추가
    ・"UnityEngine.GUIContent Temp(texture[])" 함수에 대한 후크 추가
    ・문장 번역 설정의 숫자를 통합
    ・설정에 상대 지정 추가
    ・안정성 향상
    ・배포판 : http://cafe.naver.com/kisscm/37218

  ◇1.3.6
    ・소스 코드에 주석 추가
    ・소스 코드 가독성 향상
    ・안정성 향상

  ◇1.3.5
    ・설정에 상대 지정 삭제

  ◇1.3.4
    ・설정에 날짜 별 정렬 추가

  ◇1.3.1
    ・플러그인 설정에 "TranslationRefreshKey" 설정 추가

  ◇1.2.5
    ・설정에 상대 지정 추가
    ・설정에 절대 지정 추가
    ・설정에 사용 안 함 지정 추가

  ◇1.2.4
    ・설정 파일에 속성 설정 추가

  ◇1.2.3
    ・설정 파일에 문자열 번역 설정 추가

  ◇1.2.2
    ・설정에 길이 별 정렬 추가

  ◇1.2.1
    ・플러그인 설정에 "TranslationActivateToggleKey" 설정 추가
    ・플러그인 설정에 "TranslationDefaultActivate" 설정 추가

  ◇1.1.5
    ・설정 파일에 플러그인 설정 추가

  ◇1.1.4
    ・설정 파일에 문장 번역 설정 추가

  ◇1.1.2
    ・"UnityEngine.GUIContent Temp(string)" 함수에 대한 후크 추가
    ・"UnityEngine.GUIContent Temp(Texture)" 함수에 대한 후크 추가
    ・"UnityEngine.GUIContent Temp(string, Texture)" 함수에 대한 후크 추가

  ◇1.1.1
    ・초판
